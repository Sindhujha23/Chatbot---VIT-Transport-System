LXD_URL = "http://codecompiler.etpg.in"
MYSQL_PASSWORD = ""
MYSQL_USER = "root"
DEBUG_MODE = True
LXD_USERNAME = "ibo"
LXD_PASSWORD = "ibo@ffi2016"
